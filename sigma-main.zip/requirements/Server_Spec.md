# SIGMA VPS 서버 사양

- **플랫폼**: Naver Cloud Platform (VPC 환경)
- **서버 이름**: sigma (ID: 105080454)
- **공인 IP**: 223.130.139.218
- **비공인 IP**: 10.0.1.6
- **이미지**: Ubuntu 24.04 LTS (ubuntu-24.04-base)
- **서버 사양**: s4-g3 (vCPU 4개 / 메모리 16GB)
- **스토리지**: 100GB SSD (`/dev/vda`)
- **하이퍼바이저**: KVM
- **서버 상태**: 운영 중
- **생성일시**: 2025-05-12 16:32 (KST)
- **구동일시**: 2025-05-19 19:57 (KST)
- **VPC 이름**: sigma-vpc
- **Subnet**: public-subnet1 (KR-1)
