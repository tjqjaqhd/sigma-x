# 용어 정리

| 용어 | 설명 |
| --- | --- |
| Tick | 100ms 단위 호가·체결 스냅샷 |
| Fill | 주문 체결 이벤트 |
| MODE | live/sim/backtest 모드 스위치 |
