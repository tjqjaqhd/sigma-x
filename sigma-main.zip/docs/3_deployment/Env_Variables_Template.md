# 환경 변수 예시

```
REDIS_URL=redis://localhost:6379/0
POSTGRES_URL=postgresql://user:pass@localhost:5432/sigma
SLACK_TOKEN=xxxx
```
