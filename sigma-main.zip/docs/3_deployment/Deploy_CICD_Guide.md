# 배포 및 CI/CD 가이드

GitHub Actions를 활용하여 테스트 후 Docker 이미지를 빌드하고 배포합니다. `docker compose` 파일로 단일 VPS에서 실행합니다.

자세한 서버 사양은 [../requirements/Server_Spec.md](../requirements/Server_Spec.md)을 참고하세요.
