# 전략 플러그인 명세

전략은 `StrategyManager`에 로드되며, 매 틱마다 `generate_signals()` 함수를 호출해야 합니다.
