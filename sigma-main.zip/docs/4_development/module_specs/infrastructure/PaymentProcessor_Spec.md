# SIGMA 모듈 사양서

이 문서는 SIGMA 프로젝트의 각 모듈을 명확히 기록하기 위한 문서입니다. 모든 항목은 누락 없이 작성하며, 해당 사항이 없을 경우 **해당 없음**으로 표기합니다.

## 1. 모듈 개요
* 모듈명: PaymentProcessor
* 작성자: TBD
* 작성일: 2025-05-23
* 최종 검토자: TBD
* 최종 수정일: 2025-05-23

주문 체결 이후 결제(정산) 로직을 담당한다. 거래소 또는 외부 결제 API와 연동하여
실제 자금 흐름을 확인하고 결과를 OrderExecutor에 반환한다.

## 2. 구조 개요
* 포함된 클래스/함수: `PaymentProcessor`, `request_withdrawal`, `confirm_deposit`
* 주요 메서드: `process_payment()`, `verify_balance()`
* 외부 API 제공 여부: 없음
* 소스 파일 위치: `sigma/infrastructure/payment_processor.py`

## 3. 인터페이스 명세
### 3.1 입력
* 입력 유형: 주문 체결 정보
* 형식 및 구조: `{account_id, order_id, amount, currency}`
* 제약 조건: 체결 후 1초 이내 호출
* 예시: `{"account_id":"upbit","order_id":123,"amount":100000,"currency":"KRW"}`

### 3.2 출력
* 출력 유형: 결제 상태
* 형식 및 구조: `{order_id, status, txid}`
* 예시: `{"order_id":123,"status":"confirmed","txid":"abc123"}`
* 반환 조건: 외부 API 응답이 성공적일 때

### 3.3 API 엔드포인트(해당 시)
* 해당 없음

## 4. 내부 처리 로직
* 처리 흐름 요약: 체결 정보 수신 → 외부 결제 API 호출 → 성공 여부 확인 → 결과 반환
* 순서도/플로우차트: RealTimeLoop 중 OrderExecutor 이후 단계
* 알고리즘 요약: 요청 재시도 로직과 서명 검증 포함

## 5. 예외 처리
* 주요 예외 유형: 외부 API 오류, 잔고 부족
* 발생 조건: 결제 실패 응답, 네트워크 장애
* 대응 방식: 최대 3회 재시도 후 실패 상태 반환
* 로깅/알림: 실패 시 logging_service와 NotificationService 호출

## 6. 연관 모듈 및 외부 시스템
* 상위 호출자: OrderExecutor
* 하위 호출 대상: 거래소 결제 API
* 연계되는 DB/캐시/메시지큐: PostgreSQL
* 타 모듈 간 의존 관계: SystemStatus에서 결제 성공률 모니터링

## 7. 리소스 및 성능
### 7.1 리소스 소비
* CPU 예상 사용량: 0.1 vCPU 이하
* 메모리 예상 사용량: 50MB 이하
* 병렬성 또는 멀티스레딩 여부: asyncio 사용

### 7.2 성능 기준
* 처리량 기준: 초당 수십 건 결제 확인
* 응답 시간: 평균 1초 이하
* 지연 허용 한계: 3초
* 초기화 시간: 0.5초 이하

## 8. 설정 및 의존성
* 사용하는 DB 테이블 및 필드: `payments`
* 설정값 및 기본값: `MAX_RETRY=3`, `TIMEOUT=5`
* 외부 환경 변수: `PAYMENT_API_KEY`
* 사용하는 서드파티/외부 API: 거래소 출금/입금 API

## 9. 테스트 및 검증
* 단위 테스트 항목: 잔고 확인 로직, 응답 파싱
* 예외 테스트 항목: API 오류, 네트워크 지연
* 통합 테스트 체크리스트: OrderExecutor와 연동해 전체 결제 흐름 점검
* 테스트 커버리지 목표: 80% 이상

## 10. 제약사항 및 향후 계획
* 현재 한계: 특정 거래소 API 스펙 변화에 민감
* 기술적 부채: 에러 코드별 세분화 부족
* 향후 개선/확장 예정 사항: 다중 거래소 지원, 자동 환전 기능
* 폐지 예정 요소: 없음
