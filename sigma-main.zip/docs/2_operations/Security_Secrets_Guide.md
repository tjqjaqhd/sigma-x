# 보안 및 시크릿 관리

NAVER KMS를 이용하여 API 키를 관리하며 30일마다 키를 교체합니다. GitHub Actions OIDC를 통해 배포 시점에 시크릿을 주입합니다.
